
import os, shutil, subprocess, sys
from pathlib import Path
from memoryfence.colab.session import collect_runtime, require_pilot_resources, ensure_loopback_ollama, LoopbackOllamaProcess, ollama_environment
ROOT = Path("/content/memoryfence")
assert subprocess.check_output(["git","rev-parse","HEAD"], text=True).strip() == "ce5c1f71a4c16a58d264ae3a6daa2a72c4e2c516"
print("STAGE isolated-interpreter", sys.version, flush=True)
report = collect_runtime()
print(report.model_dump_json(), flush=True)
print(require_pilot_resources(report), flush=True)
logs = Path("/content/memoryfence-session-logs")
logs.mkdir(exist_ok=True)
def command(name, args):
    print("STAGE", name, flush=True)
    result = subprocess.run(args, capture_output=True, text=True)
    (logs/(name+".log")).write_text(result.stdout+result.stderr)
    print(result.stdout[-3000:], flush=True)
    if result.returncode:
        print(result.stderr[-3000:], flush=True)
        raise SystemExit(result.returncode)
if shutil.which("ollama") is None:
    command("install-ollama", ["bash","-lc","curl -fsSL https://ollama.com/install.sh | sh"])
os.environ.update(ollama_environment())
print(ensure_loopback_ollama(executable=Path(shutil.which("ollama")), launcher=LoopbackOllamaProcess(), timeout_seconds=30), flush=True)
command("pull-candidate", ["ollama","pull","qwen2.5:0.5b"])
cli = [str(ROOT/".venv"/"bin"/"memoryfence")]
command("doctor", cli+["model","doctor"])
command("model-list", cli+["model","list"])
command("model-smoke", cli+["model","smoke","--model","qwen2.5:0.5b"])
command("compatibility-preview", cli+["experiment","preview","--config","configs/ollama-pilot.json"])
print("BOOTSTRAP_AND_SMOKE_COMPLETED", flush=True)
